
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from config import SELENIUM_WEB_URL
from helpers import open_page, wait_for


@pytest.fixture
def page(driver):
    url = f"{SELENIUM_WEB_URL}/web-form.html"
    open_page(driver, url, By.TAG_NAME, "form")
    return driver


# 1. Text, password, textarea
def test_text_fields(page):
    text = page.find_element(By.ID, "my-text-id")
    password = page.find_element(By.NAME, "my-password")
    textarea = page.find_element(By.NAME, "my-textarea")

    text.send_keys("Selenium")
    password.send_keys("Secret123")
    textarea.send_keys("Line 1\nLine 2")

    assert text.get_property("value") == "Selenium"
    assert password.get_dom_attribute("type") == "password"
    assert textarea.get_property("value") == "Line 1\nLine 2"

    text.clear()
    assert text.get_property("value") == ""


# 2. Attributes vs properties
def test_attribute_vs_property(page):
    text = page.find_element(By.ID, "my-text-id")
    text.send_keys("abc")

    assert text.get_dom_attribute("value") is None
    assert text.get_property("value") == "abc"
    assert text.get_attribute("value") == "abc"

    assert text.get_dom_attribute("myprop") == "myvalue"
    assert text.get_property("myprop") is None


# 3. Disabled and readonly
def test_disabled_and_readonly(page):
    disabled = page.find_element(By.NAME, "my-disabled")
    readonly = page.find_element(By.NAME, "my-readonly")

    assert not disabled.is_enabled()
    assert readonly.is_enabled()
    assert readonly.get_property("readOnly") is True

    assert readonly.get_property("value") == "Readonly input"


# 4. Select and datalist
def test_select_and_datalist(page):
    dropdown = Select(
        page.find_element(By.NAME, "my-select")
    )

    dropdown.select_by_visible_text("Two")

    assert dropdown.first_selected_option.get_attribute("value") == "2"

    options = page.find_elements(
        By.CSS_SELECTOR, "#my-options option"
    )

    cities = [
        option.get_attribute("value")
        for option in options
    ]

    assert len(cities) == 5
    assert "Seattle" in cities

    field = page.find_element(By.NAME, "my-datalist")
    field.send_keys("Seattle")

    assert field.get_property("value") == "Seattle"


# 5. Checkbox and radio
def test_checkbox_and_radio(page):
    checked = page.find_element(By.ID, "my-check-1")
    unchecked = page.find_element(By.ID, "my-check-2")

    assert checked.is_selected()
    assert not unchecked.is_selected()

    radio1 = page.find_element(By.ID, "my-radio-1")
    radio2 = page.find_element(By.ID, "my-radio-2")

    radio2.click()

    assert radio2.is_selected()
    assert not radio1.is_selected()


# 6. Submit form
def test_submit_form(page):
    page.find_element(
        By.ID, "my-text-id"
    ).send_keys("Selenium")

    page.find_element(
        By.CSS_SELECTOR, "form button[type='submit']"
    ).click()

    message = wait_for(page, By.ID, "message")

    assert message.text == "Received!"
    assert page.title == "Web form - target page"
    assert page.find_element(By.TAG_NAME, "h1").text == "Form submitted"
    assert "my-text=Selenium" in page.current_url
