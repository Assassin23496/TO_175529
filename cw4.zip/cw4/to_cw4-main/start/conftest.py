import pytest
from selenium import webdriver


@pytest.fixture
def driver():
    drv = webdriver.Chrome()
    drv.implicitly_wait(0)

    yield drv

    drv.quit()
