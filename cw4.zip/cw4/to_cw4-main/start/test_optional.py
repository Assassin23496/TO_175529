
import pytest
from selenium.common.exceptions import ElementNotInteractableException
from selenium.webdriver.common.by import By

from config import INTERNET_URL, SELENIUM_WEB_URL
from helpers import open_page, wait_for


# Zadanie 1 — Niepoprawny login i haslo
def test_zadanie_1_zly_login_i_haslo(driver):
    open_page(driver, f"{INTERNET_URL}/login", By.ID, "login")

    driver.find_element(By.ID, "username").send_keys("wronguser")
    driver.find_element(By.ID, "password").send_keys("wrongpassword")
    driver.find_element(By.CSS_SELECTOR, "#login button").click()

    message = wait_for(driver, By.ID, "flash")

    assert "Your username is invalid!" in message.text
    assert driver.current_url.rstrip("/").endswith("/login")


# Zadanie 2 — Zaznaczanie checkboxow
def test_zadanie_2_zaznacz_niezaznaczone_checkboxy(driver):
    open_page(driver, f"{INTERNET_URL}/checkboxes", By.ID, "checkboxes")

    checkboxes = driver.find_elements(
        By.CSS_SELECTOR, "#checkboxes input[type='checkbox']"
    )

    assert len(checkboxes) == 2
    assert [checkbox.is_selected() for checkbox in checkboxes] == [False, True]

    for checkbox in checkboxes:
        if not checkbox.is_selected():
            checkbox.click()

    assert all(checkbox.is_selected() for checkbox in checkboxes)


# Zadanie 5 — Sprawdzanie adresow e-mail w tabeli
def test_zadanie_5_wszystkie_emaile_zawieraja_malpe(driver):
    open_page(driver, f"{INTERNET_URL}/tables", By.ID, "table1")

    cells = driver.find_elements(
        By.CSS_SELECTOR, "#table1 tbody td:nth-child(3)"
    )

    emails = [cell.text.strip() for cell in cells]

    assert emails, "Nie znaleziono adresow e-mail w tabeli"
    assert all("@" in email for email in emails), (
        f"Niepoprawne adresy e-mail: {emails}"
    )


# Zadanie 8 — Obsluga wyjatku dla disabled input
def test_zadanie_8_disabled_input_wywoluje_wyjatek(driver):
    disabled_input = open_page(
        driver,
        f"{SELENIUM_WEB_URL}/web-form.html",
        By.NAME,
        "my-disabled",
    )

    assert not disabled_input.is_enabled()

    old_value = disabled_input.get_property("value")

    with pytest.raises(ElementNotInteractableException):
        disabled_input.send_keys("Selenium")

    assert disabled_input.get_property("value") == old_value
