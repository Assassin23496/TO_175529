
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from config import INTERNET_URL
from helpers import open_page, wait_for_class

URL = f"{INTERNET_URL}/tables"


def column(driver, table_id, index):
    cells = driver.find_elements(
        By.CSS_SELECTOR,
        f"#{table_id} tbody td:nth-child({index})"
    )
    return [cell.text for cell in cells]


def amounts(driver):
    cells = driver.find_elements(
        By.CSS_SELECTOR,
        "#table2 td.dues"
    )
    return [
        float(cell.text.replace("$", ""))
        for cell in cells
    ]


def test_read_column(driver):
    open_page(driver, URL, By.ID, "table1")

    assert column(driver, "table1", 1) == [
        "Smith", "Bach", "Doe", "Conway"
    ]


def test_sort_last_names(driver):
    open_page(driver, URL, By.ID, "table1")

    header = (By.CSS_SELECTOR, "#table1 th:nth-child(1)")

    driver.find_element(*header).click()

    wait_for_class(driver, header, "headerSortDown")

    WebDriverWait(driver, 10).until(
        lambda d: column(d, "table1", 1)
        == sorted(column(d, "table1", 1))
    )

    names = column(driver, "table1", 1)
    assert names == sorted(names)


def test_sort_amounts_descending(driver):
    open_page(driver, URL, By.ID, "table2")

    due = (By.CSS_SELECTOR, "#table2 th:nth-child(4)")

    driver.find_element(*due).click()
    wait_for_class(driver, due, "headerSortDown")

    driver.find_element(*due).click()
    wait_for_class(driver, due, "headerSortUp")

    WebDriverWait(driver, 10).until(
        lambda d: amounts(d)
        == sorted(amounts(d), reverse=True)
    )

    values = amounts(driver)
    assert values == sorted(values, reverse=True)
