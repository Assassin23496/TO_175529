
from selenium.webdriver.common.by import By
from config import INTERNET_URL
from helpers import open_page

URL = f"{INTERNET_URL}/add_remove_elements/"

ADD = (By.CSS_SELECTOR, "button[onclick='addElement()']")
DELETE = (By.CSS_SELECTOR, "#elements button")


def test_no_buttons_at_start(driver):
    open_page(driver, URL, *ADD)

    buttons = driver.find_elements(*DELETE)

    assert len(buttons) == 0


def test_add_three_delete_one(driver):
    add_button = open_page(driver, URL, *ADD)

    for _ in range(3):
        add_button.click()

    delete_buttons = driver.find_elements(*DELETE)

    assert len(delete_buttons) == 3

    delete_buttons[0].click()

    remaining_buttons = driver.find_elements(*DELETE)

    assert len(remaining_buttons) == 2
