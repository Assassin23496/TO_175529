
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from config import INTERNET_URL
from helpers import open_page

URL = f"{INTERNET_URL}/dropdown"


def test_dropdown_options(driver):
    dropdown = Select(open_page(driver, URL, By.ID, "dropdown"))

    texts = [option.text for option in dropdown.options]

    assert texts == [
        "Please select an option",
        "Option 1",
        "Option 2"
    ]

    assert len(dropdown.options) == 3
    assert not dropdown.options[0].is_enabled()


def test_select_option(driver):
    dropdown = Select(open_page(driver, URL, By.ID, "dropdown"))

    # Выбор по видимому тексту
    dropdown.select_by_visible_text("Option 1")
    assert dropdown.first_selected_option.text == "Option 1"

    # Выбор по значению value
    dropdown.select_by_value("2")
    assert dropdown.first_selected_option.get_attribute("value") == "2"

    # Выбор по индексу
    dropdown.select_by_index(1)
    assert dropdown.first_selected_option.text == "Option 1"
