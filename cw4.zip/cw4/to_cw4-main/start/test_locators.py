"""DevTools exercise: CSS and XPath locators.

Fill in the table: for each element enter a CSS selector
and an XPath expression (checked in DevTools: $$() and $x()).
"""
import pytest
from selenium.webdriver.common.by import By
from config import INTERNET_URL, SELENIUM_WEB_URL
from helpers import open_page

I, W = INTERNET_URL, SELENIUM_WEB_URL + "/web-form.html"
LOCATORS = [
    # 1 Username field
    (I + "/login", "#username", "//input[@id='username']"),

    # 2 Login button
    (I + "/login", "#login button[type='submit']", "//form[@id='login']//button[@type='submit']"),

    # 3 Password label
    (I + "/login", "label[for='password']", "//label[@for='password']"),

    # 4. Second checkbox
    (I + "/checkboxes",
     "#checkboxes input:nth-of-type(2)",
     "//form[@id='checkboxes']/input[2]"),

    # 5. J. Doe's email in table 2
    (I + "/tables",
     "#table2 tbody tr:nth-child(3) td.email",
     "//table[@id='table2']//tr[td[1][normalize-space()='Doe']]/td[@class='email']"),

    # 6. Due header in table 1
    (I + "/tables",
     "#table1 thead th:nth-child(4)",
     "//table[@id='table1']//thead//th[4]"),

    # 7. Add Element button
    (I + "/add_remove_elements/",
     "button[onclick='addElement()']",
     "//button[normalize-space()='Add Element']"),

    # 8. Text input field
    (W,
     "#my-text-id",
     "//input[@id='my-text-id']"),

    # 9. Disabled input field
    (W,
     "input[name='my-disabled']",
     "//input[@name='my-disabled']"),

    # 10. Dropdown option "Two"
    (W,
     "select[name='my-select'] option[value='2']",
     "//select[@name='my-select']/option[normalize-space()='Two']"),

    # 11. Submit button
    (W,
     "form button[type='submit']",
     "//form//button[normalize-space()='Submit']"),

    # 12. Return to index link
    (W,
     "a[href$='index.html']",
     "//a[normalize-space()='Return to index']"),

]


@pytest.mark.parametrize("url, css, xpath", LOCATORS)
def test_css_and_xpath(driver, url, css, xpath):
    if not css or not xpath:
        pytest.skip("TODO: fill in the locators")
    open_page(driver, url, By.CSS_SELECTOR, "#content, form")
    by_css = driver.find_elements(By.CSS_SELECTOR, css)
    by_xpath = driver.find_elements(By.XPATH, xpath)
    assert len(by_css) == 1, "CSS: expected exactly 1 element"
    assert len(by_xpath) == 1, "XPath: expected exactly 1 element"
    assert by_css[0] == by_xpath[0]           # the same element
